import React from "react";

function NotFound() {
  return (
    <div>
      <p>Not Found Page</p>
    </div>
  );
}

export default NotFound;
